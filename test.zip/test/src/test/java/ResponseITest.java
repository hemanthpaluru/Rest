import org.junit.Test;

import static io.restassured.RestAssured.given;

public class ResponseITest {

    @Test
    public void swaggerTest(){
        given().
                when().
                post("https://petstore.swagger.io/v2/pet/500").
                then().
                statusCode(404);
    }
}
